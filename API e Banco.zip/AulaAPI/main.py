from flask import Flask, render_template, request
from models import clientes, db

class App:
    def __init__(self):
        self.app = Flask(__name__)
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:''@localhost/flaskapi'
        db.init_app(self.app)
        self.defaults_routes()

    def home(self):
        user = clientes("cleber","cleber@gmail.com")
        return render_template('index.html',user=user)
    
    def clientes(self):
        if request.method == 'POST':
            try:   
                data = request.get_json()
                print(data)
                user = clientes(data['nome'], data['email'])
                db.session.add(user)
                db.session.commit()
                return 'Usuário criado com sucesso', 200
            except Exception as e:
                return 'O usuário não foi criado', 405
        
        elif request.method == 'GET':
            try:
                data = clientes.query.all()
                return render_template('clientes.html', data={'clientes':[cliente.to_dict() for cliente in data]})
            except Exception as e:
                return 'Não foi possível buscar buceta', 405
    
    def defaults_routes(self):
        self.app.route('/')(self.home)
        self.app.route('/clientes',methods=['POST','GET'])(self.clientes)

    def run(self):
        return self.app.run(port=3000, host='localhost', debug=True)
    
app = App()
app.run()