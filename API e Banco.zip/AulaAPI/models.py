from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()

class clientes(db.Model):

    def to_dict(self):
        return{
            'nome':self.nome,
            'email':self.email
        }
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100))
    email = db.Column(db.String(100))

    def __init__(self,nome,email):
        self.nome = nome
        self.email = email